from django.apps import AppConfig


class Admin12Config(AppConfig):
    name = 'admin12'
